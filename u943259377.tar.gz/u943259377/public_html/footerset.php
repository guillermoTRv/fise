<footer class="foot fixed-top">
        <div class="container">
            <div  style="padding-top:20px;"class="row">
                <div class="col-md-8">
                    Sitio elaborado mgsystems <a class='etiqa' href=http://fiseaprende.com/terminosusuario>Terminos y condiciones de uso Politicas de privacidad</a> &nbsp; 2015 &nbsp; <a class='etiqa' href='http://www.fiseaprende.com/dinamicas/cafe'><span class='glyphicon glyphicon-piggy-bank'></span> Invitar un <?php $cafe="caf�"; echo utf8_encode($cafe); ?></a> 
                </div>
            </div>
        </div>
    </footer>