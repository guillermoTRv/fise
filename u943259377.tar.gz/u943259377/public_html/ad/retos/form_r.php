<div class="form-group">
    <label>Pregunta</label>
    <input type="text" class="form-control" name='pregunta' required>
</div>

<div class="form-group">
    <label>Respuesta</label>
    <input type="text" class="form-control" name='resp' required>
</div>

<div class="form-group">
    <label>Placeholder</label>
    <input type="text" class="form-control" name='placeholder' required>
</div>

<div class="form-group">
    <label>Mensaje de salida</label>
    <input type="text" class="form-control" name='mens' required>
</div>
<div class="form-group">
    <label>Subir imagen</label>
    <input type="file" name='image' required>
</div>

<button type="submit" class="btn btn-success btn-md btn-block">Subir reto</button>
