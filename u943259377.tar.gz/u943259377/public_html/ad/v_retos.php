<h3>Subamos un reto</h3>
<br>
<div class="col-md-8">
	<form action='retos/pr.php' method='post' enctype='multipart/form-data'>
 		<?php 
	      @ include('retos/form_r.php');
	     ?>
	</form>
</div>
