<!DOCTYPE html>
<html>
<head>
  <title>Entrar</title>
  <meta name="viewport" content="width=device-width,  initial-scale=1.0">
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <link rel="stylesheet" href="../css/bootstrapset.css">
  <link rel="stylesheet" href="../js/bootstrap.js">
</head>
<body>
  <div class="container">
   <div class="row">
      <div class="col-md-4 col-md-offset-3" style="margin-top:100px;">
        <form action="nhhJJhrthAnfkaqwp21.php" method="post" enctype="multipart/form-data">
           <center><legend>A trabajar</legend></center>
           <div class="form-group">
                <center><label for="exampleInputEmail1">Email address</label></center>
                <input type="email" class="form-control" name="correo_txt" id="exampleInputEmail1" required>
           </div>

          <div class="form-group">
                <center><label for="exampleInputEmail1">Password</label></center>
                <input type="password" class="form-control" name="pass_txt"id="exampleInputEmail1" required>
          </div>
            <br>

            <center><button type="submit" style="width:200px;" class="btn btn-default">Entrar</button></center>
           
        </form>
       
      </div>
   </div> 
  </div>
</body>
</html>