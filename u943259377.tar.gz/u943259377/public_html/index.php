<!DOCTYPE html>
<html>
<head>
  <title>Matemáticas y mas</title>
  <meta name="viewport" content="width=device-width,  initial-scale=1.0">
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <link rel="stylesheet" href="css/bootstrapset.css">
  <link rel="stylesheet" href="css/inx.css">
  <link rel="shortcut icon" href="image/icono.jpg">
  <link rel="stylesheet" href="js/bootstrap.js">
  <link href="css/carousel.css" rel="stylesheet">
  <script src="http://code.jquery.com/jquery.js"></script>
        <style>.img-circle-adv {
          border-radius: 25px;
          border:solid 2px #5a5a5a;
          line-height: 1.42857143;
          padding: 4px;
        }.gjh{
        margin-left:-50px;
      }</style>
  <link href='https://fonts.googleapis.com/css?family=Indie+Flower' rel='stylesheet' type='text/css'>
<meta name="description" content="Somos un sitio en donde se recomiendan y se comparten contenidos tales como ejercicios resueltos, de práctica, videos, apuntes de cuadernos, aplicaciones digitales, textos en línea, formularios, presentaciones y sitios web relacionados con las matemáticas y las ciencias, poseemos un sistema de organización de la información que te permitirá encontrar algún material más sencillamente además de que los contenidos son calificados por la comunidad ">
<meta name="keywords" content="fiseaprede,fiseaprende.com, fise, algebra, algebra intermedia, trigonometria, estadistica descriptiva, geometria analitica, calculo, calculo integral, calculo diferencial, matematicas bachillerato, matematicas, recomendaciones matematicas, ejercicios resueltos, ejercicios de practica, videos, videos de matematicas, contenidos educativos, formularios de calculo, formularios de estadistica, integrales, diferenciales, limites, pdf matematicas, formulas, conocimiento, apuntes de matematicas, aplicaciones matematicas, aplicaciones del calculo, aplicaciones de las integrales"/>
</head>
<body>
  <?php include_once("analyticstracking.php") ?>
  <?php include("header.php") ?>

  <div class="momet">
    <div class="contmomet">
      <h1 class="aches" ALIGN=center>Explora, comparte y aprende</h1>
      <h4 class="textmomet" ALIGN=center >Únete, somos un sitio en donde se recomiendan y se comparten contenidos tales como ejercicios resueltos, de práctica, videos, apuntes de cuadernos, aplicaciones digitales, textos en línea, formularios, presentaciones y sitios web relacionados con las matemáticas y las ciencias, poseemos un sistema de organización de la información que te permitirá encontrar algún material más sencillamente además de que los contenidos son calificados por la comunidad para que tú puedas decidir en cual confiar más a la hora de estudiar, accede y encuentra más de 671 temas organizados en 9 materias</h4>
      <br>
      <p ALIGN=center><a target='_blank' href="https://www.facebook.com/ejerciciosmatematicasymas?fref=ts" class='btn btn-primary btn-lg'>Ver facebook</a></p>
    </div>
  </div>

    <?php include("mensajesbas.php"); ?>
    <div class="container marketing">
      <br>
        <?php @include("dinamicas/retos.php"); ?>
      
        <div class="gjh">
        <h2 style="font-size:2.6em;text-align:center;"><?php $jk='Catalogo de materias de Matematicas basicas'; echo utf8_encode($jk); ?></h2>
        <br>
        <br>
      </div>
        <?php @include('dinamicas/listado.php') ?>
      <br>
      <hr>
      <br>
      <div class="row">
          <center><div><h1 class="enc">Nueva sección: Recomiendame un contenido</h1></div></center>   
          <br> 
            <div class="row" style='margin-left:8px;margin-right:8px;'>
              <div class="col-md-8 col-md-offset-2">
                <?php include("prueba.php"); ?>
              </div>
            </div>
      </div>
      <br>
      <hr>
      <br>
      <p>&nbsp;</p>
      <br>
      <center><div><h1 class="enc"><?php $m='M�tematicas'; echo utf8_encode($m); ?> avanzadas</h1></div></center>
      <br>
      <br>
      <div class="row">
        <div class="col-lg-4">
          <img class="img-circle-adv" src="image/cmv.jpg" alt="Generic placeholder image" width="140" height="140">
          <h2>Calculo avanzado</h2>
          <p><a class="btn btn-default" href="http://fiseaprende.com/c-avanzado/lista-calculo" role="button">Ver indice &raquo;</a></p>
        </div>
        <div class="col-lg-4">
          <img class="img-circle-adv" src="image/lineal.jpg" alt="Generic placeholder image" width="140" height="140">
          <h2>Algebra lineal</h2>          
          <p><a class="btn btn-default" href="http://www.fiseaprende.com/lineal/lista-algebralineal" role="button">Ver indice &raquo;</a></p>
        </div>
        <div class="col-lg-4">
          <img class="img-circle-adv" src="image/ecudif.jpg" alt="Generic placeholder image" width="140" height="140">
          <h2>Ecuaciones diferenciales</h2>          
          <p><a class="btn btn-success" href='http://fiseaprende.com/diferenciales/lista-diferenciales' role="button">Ver indice &raquo;</a></p>
        </div> 
      </div>
      <br><hr><br>
         
      <div class="row">
        <div class="col-md-7 col-md-push-5">
          <h2>Algo que ayudaría mucho a mejorar la comunidad<span class="text-muted"> tómale foto a un apunte</span></h2>
          <p class="lead">El lema en fise es compartir y aprender, una dinámica que queremos tener aquí es que si tienes un ejercicio resuelto, diagrama, mapa conceptual, texto, etc, en tu cuaderno le tomes una foto y la subas, será tu buena obra del día compartir un poco de conocimiento, de seguro a alguien le servirá mucho y te lo agradecerá, además muy pronto podrás obtener un beneficio económico por ello</p>
        </div>
        <div class="col-md-5 col-md-pull-7">
          <img class="featurette-image img-responsive center-block img-thumbnail" src="image/library-488691_1280.jpg" alt="Generic placeholder image">
        </div>
      </div>

      <hr class="featurette-divider">
      
      <div class="row">
        <div class="col-md-7">
          <h2>Nuestro objetivo - Ser una grandiosa biblioteca digital  </h2>
          <p class='lead'>Queremos contribuir a organizar de una mejor manera la información sobre matemáticas y ciencias que hay en el internet, de tal que forma que el acceso a esta sea de una forma más cómoda, amena y confiable</p> 
        </div>
        <div class="col-md-5">
          <img class="featurette-image img-responsive center-block img-thumbnail" src="image/student-732012_1280.jpg" alt="Generic placeholder image">
        </div>
      </div>
      
      <hr class="featurette-divider">
      
      <div class="row">
        <div class="col-md-7 col-md-push-5">
          <h2>No somos un sitio de cursos<span class="text-muted"> pero bien</span></h2>
          <p class="lead">tu podrás estudiar aquí de forma organizada la gran variedad de temas que poseen las distintas ramas de las matemáticas, puedes tomar esta plataforma como una <strong>excelente guía </strong> para tus estudios</p>
        </div>
        <div class="col-md-5 col-md-pull-7">
          <img class="featurette-image img-responsive center-block img-thumbnail" src="image/student-732012_1280.jpg" alt="Generic placeholder image">
        </div>
      </div>

      <hr class="featurette-divider">

      <!-- /END THE FEATURETTES -->


      <!-- FOOTER -->
      <?php include('footerset.php'); ?>
    </div><!-- /.container -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://code.jquery.com/jquery.js"></script>
  <script src="js/bootstrap.min.js"></script>
</body>
</html>                 