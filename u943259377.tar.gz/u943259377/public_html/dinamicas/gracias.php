<!DOCTYPE html>
<html>
<head>
	<title>Gracias por el caf�</title>
	<meta name="viewport" content="width=device-width,  initial-scale=1.0">
	<meta http-equiv="Content-Type" content="text/html;"/>
	<link rel="stylesheet" href="../css/bootstrapset.css">
	<link rel="stylesheet" href="../css/list.css">
	<link rel="stylesheet" href="../js/bootstrap.js"> 
        <link rel="shortcut icon" href="../image/icono.jpg">

</head>
<body>
    <?php include_once("../analyticstracking.php") ?>

	<?php 
        include("../header.php");
    ?>
	<div class="container-fluid">
	    <div class="main">	
		    <div class="row">
			
				<div class="col-md-10 col-md-offset-1" >
					<div class="panel panel-default fk" style="border-radius:10px;">
						<div class="panel-body">
							<div class="row">
								<div class="col-md-9 col-md-offset-1" style='border-left:2px solid #ddd;'>
                            		<br>
                            		<h1>�Muchas gracias por tu colaboraci�n!</h1>
                            		<br>
                            		<h4>Te prometeremos que vamos a hacer un grandioso trabajo para hacer de esta, una espectacular plataforma educativa que ayude a muchas personas</h4>
                            		<br>
                            		<h4>�Que tengas un grandioso d�a usuario!</h4>
           							<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
								</div>
							</div>
						</div>
					</div>
				</div>
		    </div>
	    </div>
	</div>
	<?php include("../footerset.php") ?>
	<script src="http://code.jquery.com/jquery.js"></script>
	<script src="../js/bootstrap.min.js"></script>
</body>
</html>