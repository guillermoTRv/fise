<?php 
	if ($materia=="Algebra basica") {
		echo "<center><span class='glyphicon glyphicon-list-alt'></span><a href='http://fiseaprende.com/algintermedia/lista-algebrabasica' class='aind'> Regresar al indice</a></center><br>";
	}
        if ($materia=="Algebra intermedia") {
		echo "<center><span class='glyphicon glyphicon-list-alt'></span><a href='http://fiseaprende.com/algintermedia/lista-algintermedia' class='aind'> Regresar al indice</a></center><br>";
	}
	if ($materia=="Trigonometria") {
		echo "<center><span class='glyphicon glyphicon-list-alt'></span><a href='http://fiseaprende.com/trigonometria/lista-trigonometria' class='aind'> Regresar al indice</a></center><br>";
	}
	if ($materia=="Geometria analitica") {
		echo "<center><span class='glyphicon glyphicon-list-alt'></span><a href='http://fiseaprende.com/geometrianalitica/lista-geometria' class='aind'> Regresar al indice</a></center><br>";
	}
	if ($materia=="Estadistica") {
		echo "<center><span class='glyphicon glyphicon-list-alt'></span><a href='http://fiseaprende.com/estadistica/lista-estadistica' class='aind'> Regresar al indice</a></center><br>";
	}
	if ($materia=="Calculo diferencial") {
		echo "<center><span class='glyphicon glyphicon-list-alt'></span><a href='http://fiseaprende.com/calculodif/lista-diferencial' class='aind'> Regresar al indice</a></center><br>";
	}
	if ($materia=="Calculo integral") {
		echo "<center><span class='glyphicon glyphicon-list-alt'></span><a href='http://fiseaprende.com/calculointegral/lista-integral' class='aind'> Regresar al indice</a></center><br>";
	}
        if ($materia=="Calculo avanzado") {
		echo "<center><span class='glyphicon glyphicon-list-alt'></span><a href='http://fiseaprende.com/c-avanzado/lista-calculo' class='aind'> Regresar al indice</a></center><br>";
	}
        if ($materia=="Algebra lineal") {
		echo "<center><span class='glyphicon glyphicon-list-alt'></span><a href='http://fiseaprende.com/lineal/lista-algebralineal' class='aind'> Regresar al indice</a></center><br>";
	}
        if ($materia=="Ecuaciones diferenciales") {
		echo "<center><span class='glyphicon glyphicon-list-alt'></span><a href='http://fiseaprende.com/diferenciales/lista-diferenciales' class='aind'> Regresar al indice</a></center><br>";
	}
 ?>