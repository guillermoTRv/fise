<div class="col-md-10 col-md-offset-1">  
                            <table class="table ">
                                <thead>
                                    <tr>   
                                      <th>Unidades(clic en el nombre)</th>
                                      <th>Temas</th>
                                      <th>Contenidos</th>
                                    </tr>
                                </thead>
                                <tbody>
                  		<?php 
                         	  include("../config.php");
                                  @include("../scripts/limpias/limpiar.php");
                  		  @include("../scripts/listas/listado.php");
                  		?>
			      </tbody>
                            </table>
</div>