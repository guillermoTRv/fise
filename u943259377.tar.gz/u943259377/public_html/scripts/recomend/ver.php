<?php 
	if ($materia=="Algebra basica") {
		echo "
                <a class='lnk' href='http://fiseaprende.com/basica/recobas?rec=$id_r'>
            ";
	}
	if ($materia=="Algebra intermedia") {
		echo "
                <a class='lnk' href='http://fiseaprende.com/algintermedia/recoalg?rec=$id_r'>
            ";
	}
	if ($materia=="Trigonometria") {
		echo "
                <a class='lnk' href='http://fiseaprende.com/trigonometria/recotrig?rec=$id_r'>
            ";
	}
	if ($materia=="Geometria analitica") {
		echo "
                <a class='lnk' href='http://fiseaprende.com/geometrianalitica/recogeo?rec=$id_r'>
            ";
	}
	if ($materia=="Estadistica") {
		echo "
                <a class='lnk' href='http://fiseaprende.com/estadistica/recoest?rec=$id_r'>
            ";
	}
	if ($materia=="Calculo diferencial") {
		echo "
                <a class='lnk' href='http://fiseaprende.com/calculodif/recodif?rec=$id_r'>
            ";
	}
	if ($materia=="Calculo integral") {
		echo "
                <a class='lnk' href='http://fiseaprende.com/calculointegral/recoint?rec=$id_r'>
            ";
	}
        if ($materia=="Calculo avanzado") {
		echo "
                <a class='lnk' href='http://fiseaprende.com/c-avanzado/recocalculo?rec=$id_r'>
            ";
	}
        if ($materia=="Algebra lineal") {
		echo "
                <a class='lnk' href='http://fiseaprende.com/lineal/recolineal?rec=$id_r'>
            ";
	}
        if ($materia=="Ecuaciones diferenciales") {
		echo "
                <a class='lnk' href='http://fiseaprende.com/diferenciales/recodiferenciales?rec=$id_r'>
            ";
	}
 ?>