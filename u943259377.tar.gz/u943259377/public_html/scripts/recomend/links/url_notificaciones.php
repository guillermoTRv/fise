<?php 
	if ($materia=="Algebra basica") {
		global $notif;
        $notif="http://fiseaprende.com/basica/recobas?rec=$id_reco";
              
	}
	if ($materia=="Algebra intermedia") {
		global $notif;
        $notif="http://fiseaprende.com/algintermedia/recoalg?rec=$id_reco";
                    
	}
	if ($materia=="Trigonometria") {
		global $notif;
        $notif="http://fiseaprende.com/trigonometria/recotrig?rec=$id_reco";
        
	}
	if ($materia=="Geometria analitica") {
		global $notif;
        $notif="http://fiseaprende.com/geometrianalitica/recogeo?rec=$id_reco";

	}
	if ($materia=="Estadistica") {
		global $notif;
        $notif="http://fiseaprende.com/estadistica/recoest?rec=$id_reco";

	}
	if ($materia=="Calculo diferencial") {
		global $notif;
        $notif="http://fiseaprende.com/calculodif/recodif?rec=$id_reco";

	}
	if ($materia=="Calculo integral") {
		global $notif;
        $notif="http://fiseaprende.com/calculointegral/recoint?rec=$id_reco";

	}
        if ($materia=="Calculo avanzado") {
                global $notif;
        $notif="http://fiseaprende.com/c-avanzado/recocalculo?rec=$id_reco";
        
        }
        if ($materia=="Algebra lineal") {
                global $notif;
        $notif="http://fiseaprende.com/lineal/recolineal?rec=$id_reco";
        }
        if ($materia=="Ecuaciones diferenciales") {
                global $notif;
        $notif="http://fiseaprende.com/diferenciales/recodiferenciales?rec=$id_reco";
        }

 ?>	
	