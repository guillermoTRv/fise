<?php 
	if ($materia=="Algebra basica") {
		echo "
                <a style='text-decoration:none' href='http://fiseaprende.com/basica/recobas'>
                    <p class='lreco'><span class='glyphicon glyphicon-comment'></span>
                        ver mas ...
                    </p>
                </a>
            ";
	}
	if ($materia=="Algebra intermedia") {
		echo "
                <a style='text-decoration:none' href='http://fiseaprende.com/algintermedia/recoalg'>
                    <p class='lreco'><span class='glyphicon glyphicon-comment'></span>
                        ver mas ...
                    </p>
                </a>
            ";
	}
	if ($materia=="Trigonometria") {
		echo "
                <a style='text-decoration:none' href='http://fiseaprende.com/trigonometria/recotrig'>
                    <p class='lreco'><span class='glyphicon glyphicon-comment'></span>
                        ver mas ...
                    </p>
                </a>
            ";
	}
	if ($materia=="Geometria analitica") {
		echo "
                <a style='text-decoration:none' href='http://fiseaprende.com/geometrianalitica/recogeo'>
                    <p class='lreco'><span class='glyphicon glyphicon-comment'></span>
                        ver mas ...
                    </p>
                </a>
            ";
	}
	if ($materia=="Estadistica") {
		echo "
                <a style='text-decoration:none' href='http://fiseaprende.com/estadistica/recoest'>
                    <p class='lreco'><span class='glyphicon glyphicon-comment'></span>
                        ver mas ...
                    </p>
                </a>
            ";
	}
	if ($materia=="Calculo diferencial") {
		echo "
                <a style='text-decoration:none' href='http://fiseaprende.com/calculodif/recodif'>
                    <p class='lreco'><span class='glyphicon glyphicon-comment'></span>
                        ver mas ...
                    </p>
                </a>
            ";
	}
	if ($materia=="Calculo integral") {
		echo "
                <a style='text-decoration:none' href='http://fiseaprende.com/calculointegral/recoint'>
                    <p class='lreco'><span class='glyphicon glyphicon-comment'></span>
                        ver mas ...
                    </p>
                </a>
            ";
	}
        if ($materia=="Calculo avanzado") {
		echo "
                <a style='text-decoration:none' href='http://fiseaprende.com/c-avanzado/recocalculo'>
                    <p class='lreco'><span class='glyphicon glyphicon-comment'></span>
                        ver mas ...
                    </p>
                </a>
            ";
	}
        if ($materia=="Algebra lineal") {
		echo "
                <a style='text-decoration:none' href='http://fiseaprende.com/lineal/recolineal'>
                    <p class='lreco'><span class='glyphicon glyphicon-comment'></span>
                        ver mas ...
                    </p>
                </a>
            ";
	}
        if ($materia=="Ecuaciones diferenciales") {
		echo "
                <a style='text-decoration:none' href='http://fiseaprende.com/diferenciales/recodiferenciales'>
                    <p class='lreco'><span class='glyphicon glyphicon-comment'></span>
                        ver mas ...
                    </p>
                </a>
            ";
	}
 ?>