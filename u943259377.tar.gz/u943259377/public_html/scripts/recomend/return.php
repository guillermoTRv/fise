<?php 
	if ($materia=="Algebra basica") {
		echo "
			<a class='lnk' href='http://fiseaprende.com/basica/recobas'><span class='glyphicon glyphicon-repeat'></span> Regresar</a>
		";
	}
	if ($materia=="Algebra intermedia") {
		echo "
			<a class='lnk' href='http://fiseaprende.com/algintermedia/recoalg'><span class='glyphicon glyphicon-repeat'></span> Regresar</a>
		";
	}
	if ($materia=="Trigonometria") {
		echo "
			<a class='lnk' href='http://fiseaprende.com/trigonometria/recotrig'><span class='glyphicon glyphicon-repeat'></span> Regresar</a>
		";
	}
	if ($materia=="Geometria analitica") {
		echo "
			<a class='lnk' href='http://fiseaprende.com/geometrianalitica/recogeo'><span class='glyphicon glyphicon-repeat'></span> Regresar</a>
		";
	}
	if ($materia=="Estadistica") {
		echo "
			<a class='lnk' href='http://fiseaprende.com/estadistica/recoest'><span class='glyphicon glyphicon-repeat'></span> Regresar</a>
		";
	}
	if ($materia=="Calculo diferencial") {
		echo "
			<a class='lnk' href='http://fiseaprende.com/calculodif/recodif'><span class='glyphicon glyphicon-repeat'></span> Regresar</a>
		";
	}
	if ($materia=="Calculo integral") {
		echo "
			<a class='lnk' href='http://fiseaprende.com/calculointegral/recoint'><span class='glyphicon glyphicon-repeat'></span> Regresar</a>
		";
	}
        if ($materia=="Calculo avanzado") {
		echo "
			<a class='lnk' href='http://fiseaprende.com/c-avanzado/recocalculo'><span class='glyphicon glyphicon-repeat'></span> Regresar</a>
		";
	}
        if ($materia=="Algebra lineal") {
		echo "
			<a class='lnk' href='http://fiseaprende.com/lineal/recolineal'><span class='glyphicon glyphicon-repeat'></span> Regresar</a>
		";
	}
        if ($materia=="Algebra lineal") {
		echo "
			<a class='lnk' href='http://fiseaprende.com/diferenciales/recodiferenciales'><span class='glyphicon glyphicon-repeat'></span> Regresar</a>
		";
	}
 ?>