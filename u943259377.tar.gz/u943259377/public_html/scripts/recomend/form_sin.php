<?php echo "
    <div style='margin-top:50px;margin-right:-17px;' class='modal fade' id='$id_r' tabindex='-1' role='dialog' aria-labelledby='myModalLabel'>"; ?>
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <h5>Debes de inciar sesi�n o registrarte para poder responder</h5>
                </div>
                <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
                
                </div>
            </div>
        </div>
    </div>
