<div style="margin-top:50px;margin-right:-17px;" class="modal fade" id="guardar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Agregar contenido</h4>
			</div>
			<div class="modal-body">
				<h5>Debes de inciar sesión o registrarte para poder añadir contenidos</h5>	
			</div>
			<div class="modal-footer">
			    <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
			</div>
		</div>
	</div>
</div>