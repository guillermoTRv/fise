<?php
	if ($un!='' && $tm=='') {
            echo "<h3 class='fun'>$materia $un</h3>";
        }
    if ($un!='' && $tm!='') {
    	    echo "<h3 class='fun'>$materia $tm</h3>";
    }
    if ($u=='Subir') {
            echo "<h3 class='fun'>$materia $u</h3>";
    }
 ?>