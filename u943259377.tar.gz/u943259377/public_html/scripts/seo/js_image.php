<?php 
	if ($sub!='') {
		echo $js1='<script type="text/javascript" src="../js/agregarNuevaFila.js"></script>';
		echo $js2='<script type="text/javascript" src="../js/modificarEstiloInputFile.js"></script>';
	}
 ?>