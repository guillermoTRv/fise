<?php 
	if ($cont!='') {
		$meta="<meta name='description' content='$descri'>";
		echo $meta;
	}
	if ($u=='Subir') {
		$meta="<meta name='description' content='En esta secci�n tu podr�s compartir un contenido con la comunidad, ya sea que conozcan un buen v�deo, una buena pagina de internet, una aplicaci�n web o un apunte que tengas en tu cuaderno aqu� podr�s hacerlo'>";
		echo $meta;
	}
 ?>