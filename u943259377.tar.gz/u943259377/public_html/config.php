<?php 
	function conectarse()
	{
		$servidor="mysql.hostinger.mx";
		$usuario="u943259377_ggv";
		$password="fr32wopnn510";
		$bd="u943259377_fisea";

		$conectar=new mysqli($servidor, $usuario, $password, $bd);
		return $conectar;
	}	
$conexion = conectarse();
 ?>