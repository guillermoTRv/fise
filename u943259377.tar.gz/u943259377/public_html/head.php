	<!DOCTYPE html>
	<html>
	<head>
	  <title>Matemáticas y mas</title>
	  <meta name="viewport" content="width=device-width,  initial-scale=1.0">
	  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	  <link rel="stylesheet" href="css/bootstrapset.css">
	  <link rel="stylesheet" href="css/inx.css">
	  <link rel="shortcut icon" href="image/icono.jpg">
	  <link rel="stylesheet" href="js/bootstrap.js">
	  <link href="css/carousel.css" rel="stylesheet">
	  <script src="http://code.jquery.com/jquery.js"></script>
			<style>.img-circle-adv {
			  border-radius: 25px;
			  border:solid 2px #5a5a5a;
			  line-height: 1.42857143;
			  padding: 4px;
			}.gjh{
			margin-left:-50px;
		  }</style>
	  <link href='https://fonts.googleapis.com/css?family=Indie+Flower' rel='stylesheet' type='text/css'>
	<meta name="description" content="Somos un sitio en donde se recomiendan y se comparten contenidos tales como ejercicios resueltos, de práctica, videos, apuntes de cuadernos, aplicaciones digitales, textos en línea, formularios, presentaciones y sitios web relacionados con las matemáticas y las ciencias, poseemos un sistema de organización de la información que te permitirá encontrar algún material más sencillamente además de que los contenidos son calificados por la comunidad ">
	<meta name="keywords" content="fiseaprede,fiseaprende.com, fise, algebra, algebra intermedia, trigonometria, estadistica descriptiva, geometria analitica, calculo, calculo integral, calculo diferencial, matematicas bachillerato, matematicas, recomendaciones matematicas, ejercicios resueltos, ejercicios de practica, videos, videos de matematicas, contenidos educativos, formularios de calculo, formularios de estadistica, integrales, diferenciales, limites, pdf matematicas, formulas, conocimiento, apuntes de matematicas, aplicaciones matematicas, aplicaciones del calculo, aplicaciones de las integrales"/>
	</head>
	<body>
