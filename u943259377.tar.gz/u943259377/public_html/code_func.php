<?php

function echoFise($string){
	echo ($string);
	//echo iconv("UTF-8", "Windows-1252", $string);
	return;
}




?>