<?php 
	if ($materia_c=="Algebra basica") {
		echo "Hola";
	}
	if ($materia_c=="Trigonometria") {
		echo "monica";
	}
 ?>