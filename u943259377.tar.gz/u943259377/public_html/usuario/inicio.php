<div class="col-md-9 col-xs-12 boruser" >
                            <div class="media">
                                <div class="media-left hidden-xs">
                                    <img class="imgcoment" src="http://mertasan.com/upload/resimler/020ce1ab3b.jpg" alt="Generic placeholder image" width="110px" height="120px" >
                                </div>
                                <?php include("inicio/encabezado.php") ?>
                            </div>
                            <hr>
                            
                            <div class="row">
                                <div class="col-md-8">
                                    <h4>Notificaciones y actividad reciente</h4>
                                    <ul style="list-style:none;">
                                        <?php include("inicio/notificaciones.php"); ?>
                                    </ul>
                                </div>


                            </div>
                            <hr>
                            <h4 style="margin-top:24px;">
                                Informacion general 
                            </h4>
                                <?php include("inicio/infogen.php"); ?>

                            <hr>
                            <h4 style="margin-top:24px;">
                                Sacale provecho  
                            </h4>
				<p class="prove">Recuerden que aquí se trata de compartir solo los mejores contenidos que hay en Internet sobre matemáticas</p>
				<p class="prove">Si tienes un apunte en tu cuaderno o conoces algún buen material en linea que pueda ser de utilidad no dudes en compartirlo en alguna de las materias que tenemos aquí./</p>
                                <p class="prove">Recuerda que los puntos los podrás ocupar para crear listas y añadir preferencias</p>
				<p class="prove">Se modificaron términos y condiciones de uso, ultima linea</p>
                            <hr>
                            <h4 style="margin-top:24px;">
                                Mis puntos
                            </h4>
                            <ul class="ulpoint">
                                <?php include("inicio/mispuntos.php") ?>
                                <br>
                                
                            </ul>

                        </div>			