<?php 
	if ($materia=="Algebra basica"){
		echo "<a class='fik' href='http://fiseaprende.com/basica/panelalgbas?un=$unidad&cont=$id_fichabas'>";
	} 
	if ($materia=="Algebra intermedia") {
		echo "<a class='fik' href='http://fiseaprende.com/algintermedia/panelalg?un=$unidad&cont=$id_fichabas'>";
	}
	if ($materia=="Trigonometria") {
		echo "<a class='fik' href='http://fiseaprende.com/trigonometria/paneltrig?un=$unidad&cont=$id_fichabas'>";
	}
	if ($materia=="Geometria analitica") {
		echo "<a class='fik' href='http://fiseaprende.com/geometrianalitica/panelgeo?un=$unidad&cont=$id_fichabas'>";
	}
	if ($materia=="Estadistica") {
		echo "<a class='fik' href='http://fiseaprende.com/estadistica/panelest?un=$unidad&cont=$id_fichabas'>";
	}
	if ($materia=="Calculo diferencial") {
		echo "<a class='fik' href='http://fiseaprende.com/calculodif/paneldif?un=$unidad&cont=$id_fichabas'>";
	}
	if ($materia=="Calculo integral") {
		echo "<a class='fik' href='http://fiseaprende.com/calculointegral/panelint?un=$unidad&cont=$id_fichabas'>";
	}
        if ($materia=="Calculo avanzado") {
		echo "<a class='fik' href='http://fiseaprende.com/c-avanzado/panelcalculo?un=$unidad&cont=$id_fichabas'>";
	}
        if ($materia=="Algebra lineal") {
		echo "<a class='fik' href='http://fiseaprende.com/lineal/panel-lineal?un=$unidad&cont=$id_fichabas'>";
	}
?>