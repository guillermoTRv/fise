<label class='control-label'>Tema</label>
            <select id='modelo' class='form-control input-sm curselect' name='tema_slc' title='Selecciona un tema'>
            <option value='' >---</option>
            </select><br>