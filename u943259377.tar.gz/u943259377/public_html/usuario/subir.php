<div class="col-md-9 boruser">
    <div class="row">
        <div class="col-md-5"><h3><span class="glyphicon glyphicon-cloud-upload"></span> Subir un contenido</h3></div>
    </div>
    <hr>
    <p style="font-family">Gracias por compartir con la comunidad</p>

    <a class="fik" target='_blank' href="http://www.fiseaprende.com/basica/panelalgbas?un=1-Suma,%20resta,%20multiplicaci%C3%B3n%20algebraica%20y%20uso%20de%20par%C3%A9ntesis&sub=true">Subir en Algebra básica</a>
    <br>
    <a class="fik" target='_blank' href="http://www.fiseaprende.com/algintermedia/panelalg?un=1-Gr%C3%A1ficas%20y%20funciones&sub=true">Subir en Algebra intermedia</a>
    <br>
    <a class="fik" target='_blank' href="http://www.fiseaprende.com/trigonometria/paneltrig?un=1-Medidas%20y%20razones%20de%20los%20triangulos%20rectangulos&sub=true">Subir en Trigonometría</a>
    <br>
    <a class="fik" target='_blank' href="http://www.fiseaprende.com/geometrianalitica/panelgeo?un=1-Gr%C3%A1ficas%20y%20funciones&sub=true">Subir en Geometría analítica</a>
    <br>
    <a class="fik" target='_blank'href="http://www.fiseaprende.com/estadistica/panelest?un=Conceptos%20b%C3%A1sicos%20en%20la%20estad%C3%ADstica&sub=true">Subir en Estadística</a>
    <br>
    <a class="fik" target='_blank'href="http://www.fiseaprende.com/calculodif/paneldif?un=Limites%20y%20continuidad&sub=true">Subir en Calculo Diferencial</a>
    <br>
    <a class="fik" target='_blank'href="http://www.fiseaprende.com/calculointegral/panelint?un=Introduccion%20a%20la%20integraci%C3%B3n&sub=true">Subir en Calculo Integral</a>
</div>