<div class="modal fade" id="leer" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Términos y condiciones para subir un contenido</h4>
      </div>
      <div class="modal-body">
        <h4>Al subir un contenido usted acepta los siguientes terminos</h4>
        <p>1-El contenido sera eliminado en el caso de que sea contenido delictivo, violento, pornográfico, racista, xenofóbico, ofensivo, de apología terrorista o en general, contrarios a la ley o al orden público</p>
        <p>2-Citar párrafos de algún texto protegido por derecho de autor no sera objeto de ser eliminado ya que no se esta lucrando con ello y solo es una labor de compartir conocimiento, en caso de que un autor reconozca el texto como obra suya podrá solicitar vía correo electrónico a villagran_gg@hotmail.com eliminar el contenido y hacer que se reconozca sintiéndolo en la publicacion del contenido</p>
        <p>3-Queda prohibido publicar obras completas con derechos de autor</p>
	<p>4-En caso de que su contenido sea revisado y este no coincida con el la unidad y el tema que usted le haya asignado, los administradores de este sitio podrán moverlo a otra elección de unidad y tema o simplemente el tema con el fin de organizar mejor el contenido, esperemos que esto no le cause molestias</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Entendido</button>
      </div>
    </div>
  </div>
</div>