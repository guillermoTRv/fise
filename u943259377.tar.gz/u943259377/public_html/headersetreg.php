<div class="container">
		<header>
			<nav class="navbar navbar-default navbar-fixed-top">
				<div class="container">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-1" aria-expanded="false">
        				<span class="sr-only"></span>
        				<span class="icon-bar"></span>
        				<span class="icon-bar"></span>
        				<span class="icon-bar"></span>
      					</button>
						<a style="font-size:1.45em;" href="http://fiseaprende.com" class="unodos navbar-brand">Fise</a>
					</div>
					<div class="collapse navbar-collapse" id="navbar-1">
						<ul class="nav navbar-nav">
							<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Materias<span class="caret"></span></a>
								<ul class="dropdown-menu hoverhead" aria-labelledby='dropdownMenu1'>
            						<li><a href="http://fiseaprende.com/basica/lista-algebrabasica">Algebra basica</a></li>
            						<li><a href="http://fiseaprende.com/algintermedia/lista-algintermedia">Algebra intermedia</a></li>
            						<li><a href="http://fiseaprende.com/trigonometria/lista-trigonometria">Trigonometria</a></li>
            						<li><a href="http://fiseaprende.com/geometrianalitica/lista-geometria">Geometria</a></li>
            						<li><a href="http://fiseaprende.com/estadistica/lista-estadistica">Estadistica</a></li>
            						<li><a href="http://fiseaprende.com/calculodif/lista-diferencial">Calculo Diferencial</a></li>
            						<li><a href="http://fiseaprende.com/calculointegral/lista-integral">Calculo Integral</a></li>
                                                        <li><a href="http://fiseaprende.com/c-avanzado/lista-calculo">Calculo Avanzado</a></li>
                                                        <li><a href="http://fiseaprende.com/lineal/lista-algebralineal">Algebra lineal</a></li>                                                    
                                                        <li><a href="http://fiseaprende.com/diferenciales/lista-diferenciales">Ecuaciones Diferenciales</a></li>
            					</ul>
							</li>
						</ul>
						<ul class="nav navbar-nav navbar-right">
							
							<li><a href="#ventana1" data-toggle="modal"><span class="glyphicon glyphicon-log-in"></span> Iniciar Sesion&nbsp;&nbsp;</a></li>

							<li><a href="#ventana2" data-toggle="modal"><span class="glyphicon glyphicon-edit"></span> Registrate&nbsp;&nbsp;</a></li>
						</ul>
					</div>
				</div>
			</nav>
			<?php include("formulario_login.php"); include("formulario_registro.php");?>
		     
	    </header>
 	</div>	