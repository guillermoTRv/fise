<?php
	$apuntes="apuntes-usuarios";
	$series="examenes-o-series";
	$api="aplicaciones-digitales"; 
	echo"
 	<li><a href='?un=$u&by=videos'>Videos</a></li>
 	<li><a href='?un=$u&by=presentaciones'>Presentaciones</a></li>
 	<li><a href='?un=$u&by=$apuntes'>Apuntes usuarios</a></li>
 	<li><a href='?un=$u&by=pdf'>PDF</a></li>
 	<li><a href='?un=$u&by=$series'>Exámenes o series</a></li>
 	<li><a href='?un=$u&by=$api'>Aplicaciones digitales</a></li>
 	<li><a href='?un=$u&by=retos'>Retos</a></li>
 	<li><a href='?un=$u&by=sitios'>Sitio web</a></li>
 	<li><a href='?un=$u&by=formularios'>Formularios y temarios</a></li>
	<li><a href='?un=$u&by=otros'>Otros</a></li>
 ";?>