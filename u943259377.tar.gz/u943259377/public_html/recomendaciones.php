<div style='margin-top:35px;' class="modal fade" id="reco" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-body">
        <br>
        <p class="recp">1-Selecciona adecuadamente la unidad o tema con el que esta relacionado el contenido que vas a subir</p>
        <p class="recp">2-En caso de tener problemas con lo anterior selecciona la opción generales</p>
        <p class="recp">3-En caso de que tu contenido sea un ejercicio o problema, marca el cuadro "Ejercicio-Problema"</p>
        <p class="recp">4-Escribe un titulo que sea descriptivo del contenido no mayor a 150 caracteres</p>
        <p class="recp">5-Si lo requieres puedes agregar mas texto que no sobrepase los 1000 caracteres en el campo mas grande del formulario</p>
        <p class="recp">6-El campo link es opcional, pero en caso de que lo que compartas sea un contenido en internet, la dirección deberá ser pegada en ese campo</p>
        <p class="recp">7-Puedes subir hasta un máximo de 10 imágenes no mayores a un peso de 4mb y del tipo PNG,JPG,JPGE y GIF</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Ok</button>
      </div>
    </div>
  </div>
</div>